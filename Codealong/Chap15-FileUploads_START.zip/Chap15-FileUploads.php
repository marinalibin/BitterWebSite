<?php
//chapter 15 file uploads (sprint #3)
?>
<form action="chap15_proc.php" method="post" >
	Select your image (Must be under 1MB in size): 
	<input type="text" name="pic" required><br><br>
	<input id="button" type="submit" name="submit" value="Submit">
</form>
